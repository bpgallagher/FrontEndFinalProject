var user;

// Your web app's Firebase configuration
// Your web app's Firebase configuration
var firebaseConfig = {
    apiKey: "AIzaSyDqFkUBmQuGzSQxhaO9nq5MX0WmFaQjZ18",
    authDomain: "todo-e4962.firebaseapp.com",
    databaseURL: "https://todo-e4962.firebaseio.com",
    projectId: "todo-e4962",
    storageBucket: "todo-e4962.appspot.com",
    messagingSenderId: "651208771402",
    appId: "1:651208771402:web:b1fd40ddbc33adb28f23b3",
    measurementId: "G-HB3DPXGTDT"
};

// Initialize Firebase
firebase.initializeApp(firebaseConfig);
firebase.analytics();

var auth = firebase.auth();
//var user = firebase.auth().currentUser;



$(document).on("submit", "#form-signin", function (event) {
    event.preventDefault();
    var promise = auth.signInWithEmailAndPassword(
        $("#signin_email").val(),
        $("#signin_password").val()
    );
    //console.log(promise);

    promise.catch((e) => {
        console.log("on submit login catch e.message:");
        console.log(e.message);
        $("#alert-signin").text(e.message);
        $("#alert-signin").show();
    });
    location.replace("login.html");

    auth.onAuthStateChanged((firebaseUser) => {
        if (firebaseUser) {
            console.log(firebaseUser.email);
            let userEmail = firebaseUser.email;
            localStorage.setItem("user", userEmail);
            location.replace("blackboard.html");
        } else {
            user = null;
            console.log("not logged in");
            alert("Try login again or create new account.");
        }
    });
    
});


