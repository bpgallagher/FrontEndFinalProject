
let lectureArray = [
    'https://www.youtube.com/embed/vArd5ZPoAt0',
    'https://www.youtube.com/embed/T_fcf3YFsxc',
    'https://www.youtube.com/embed/gKpDJDMpQXs',
    'https://www.youtube.com/embed/yxqfQQkmrL8',
    'https://www.youtube.com/embed/kYxBG1jB7fI',
    'https://www.youtube.com/embed/YZU2okF4qBc',
    'https://www.youtube.com/embed/v9kCRjT7zaw',
    'https://www.youtube.com/embed/xwMLQfh3l_A',
    'https://www.youtube.com/embed/O2FbM66q1EI',
    'https://www.youtube.com/embed/HdrlLvvlmbw',
    'https://www.youtube.com/embed/ojDOVVSryQY'
];

let slidesArray = [
    'https://drive.google.com/file/d/1RfuKYwUB7CS7-pdpPpPs2iR95qg-_eMj/preview',
    'https://drive.google.com/file/d/1hb0r32oRDIoe3Wu0mOyjYCgNfJVis58x/preview',
    'https://drive.google.com/file/d/1BZmu0rU-x0UUrdS4dV81jFKJs12OiWhX/preview',
    'https://drive.google.com/file/d/1GJiDoVfC_1mRnNNT-zXXM0Ht_We4B-C7/preview',
    'https://drive.google.com/file/d/16ZyPGftWQvIdpYru6LvDVLHIUXRYf1fm/preview',
    'https://drive.google.com/file/d/1ZUuSV9Gp28xm4uPH0m3fRcp_Lu1jcjLN/preview',
    'https://drive.google.com/file/d/1oPBDoUq9PLT5pX1wN-9J_O0RgeY6WxaX/preview',
    'https://drive.google.com/file/d/19MswWUrircfT9gykaZYGxz6Z1L0Dnaag/preview',
    'https://drive.google.com/file/d/16UCVxya6jOdmEr7kG5TV0YOJm7zxnIvh/preview',
    'https://drive.google.com/file/d/13_DIaieR7DTDz4Ux_KYfSrY_UfSEmlZO/preview',
    'https://drive.google.com/file/d/1WuXR_5soVAlWWmCIge4Yyt5u53mapFIE/preview'
];





window.addEventListener(
    "resize",
    function () {
        // Get screen size (inner/outerWidth, inner/outerHeight)
        var frameInnerWidth = window.innerWidth;
        //console.log("Inner width of frame is: " + frameInnerWidth);

        var frameInnerHeight = window.innerHeight;
        //console.log("Inner height of frame is: " + frameInnerHeight);

        var resetMapHeight = ((window.innerHeight - (window.screen.height - window.screen.availHeight) * 3) / 2) + 25;
        resetMapHeight += "px";
        document.documentElement.style.setProperty("--map-height", resetMapHeight);
        return resetMapHeight;
    },
    false
);



// Get the Sidebar
var mySidebar = document.getElementById("mySidebar");

// Get the DIV with overlay effect
var overlayBg = document.getElementById("myOverlay");

// Toggle between showing and hiding the sidebar, and add overlay effect
function w3_open() {
    if (mySidebar.style.display === 'block') {
        mySidebar.style.display = 'none';
        overlayBg.style.display = "none";
    } else {
        mySidebar.style.display = 'block';
        overlayBg.style.display = "block";
    }
}

// Close the sidebar with the close button
function w3_close() {
    mySidebar.style.display = "none";
    overlayBg.style.display = "none";
}


function outerAccordion(accordionID) {
    var x = document.getElementById(accordionID);
    if (x.className.indexOf("w3-show") == -1) {
        x.className += " w3-show";
        //x.previousElementSibling.className += " w3-black";
    } else {
        x.className = x.className.replace(" w3-show", "");
        //x.previousElementSibling.className =
        //x.previousElementSibling.className.replace(" w3-black", "");
    }
}

function innerAccordion(accordionID) {
    var x = document.getElementById(accordionID);
    if (x.className.indexOf("w3-show") == -1) {
        x.className += " w3-show";
        //x.previousElementSibling.className += " w3-white";
    } else {
        x.className = x.className.replace(" w3-show", "");
        //x.previousElementSibling.className =
        //x.previousElementSibling.className.replace(" w3-white", "");
    }
}


function loadLecture(videoUrl, slideUrl) {
    console.log("loadLecture started...");
    console.log(videoUrl);
    console.log(slideUrl);
    $("#lectureIframe").attr("src", videoUrl);
    $("#slideObject").attr("data", slideUrl);
    $("#slideEmbed").attr("src", slideUrl);
}




$(document).ready(function () {
    $('#notePad').keypress(function (event) {
        var keycode = (event.keyCode ? event.keyCode : event.which);
        if (keycode == '13') {
            let timeElement = document.createElement("time");
            let ytplayer = document.getElementById("player");
            let ytPlayerTime = ytplayer.getCurrentTime();
            console.log("ytPlayerTime: " + ytPlayerTime);
            timeElement.setAttribute("datetime", ytPlayerTime);
            timeElement.innerHTML = ytPlayerTime;
            console.log(timeElement);

            $('#notePad').innerHTML = timeElement
            alert('You pressed the "enter" key in textbox');
        }
        //Stop the event from propogation to other handlers
        //If this line will be removed, then keypress event handler attached 
        //at document level will also be triggered
        event.stopPropagation();
    });
});



/*
    $(document).ready(function () {
        $('#notePad').bind('keyup', function () {
            var content = $(this).val();
            setTitle(content);
            setLineNumber(content);
            console.log(content);
        });

        $('#notePad').bind('focus click', function () {
            var content = $(this).val();
            setLineNumber(content);
        });
    });

    function setTitle(content) {
        var lines = content.split('\n');

        for (i = 0; i < lines.length; i++) {
            if (lines[i].trim().length > 0) {
                document.title = lines[i];
                return 0;
            }
        }

        document.title = "Notepad";
    }

    function setLineNumber(content) {
        var lineNumber = content.substr(0, $('#notePad').prop('selectionStart')).split("\n").length;
        console.log(`lineNumber: ${lineNumber}`);
        $('#lineNumber').html(lineNumber);
    }
    */

